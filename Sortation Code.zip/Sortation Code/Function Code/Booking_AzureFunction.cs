﻿#r "System.Configuration"
#r "System.Data"
#r "Newtonsoft.Json"
#r "System.Net"
#r "System.Net.Http"
#r "System"

using System;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using Newtonsoft.Json;
using System.Net.Mail;

static var sqlConnectionString = ConfigurationManager.ConnectionStrings["operations_sqldb_connection"].ConnectionString;
static var sqlConnection = new SqlConnection(sqlConnectionString);
static var apiKey = ConfigurationManager.AppSettings["COSMOS_API_KEY"];
static var apiEndPoint = ConfigurationManager.AppSettings["COSMOS_API_ENDPOINT"];
static var cpBookingAPI_ClientCode = ConfigurationManager.AppSettings["CP_BOOKING_API_CLIENT_CODE"];
static var cpBookingAPI_ServiceID = ConfigurationManager.AppSettings["CP_BOOKING_API_SERVICE_ID"];
static var cpBookingAPI_Endpoint = ConfigurationManager.AppSettings["CP_BOOKING_API_ENDPOINT"];

static var password = ConfigurationManager.AppSettings["SEND_MAIL_CREDENTIALS_PASSWORD"];
static var username = ConfigurationManager.AppSettings["SEND_MAIL_CREDENTIALS_USERNAME"];
static var fromEmailAddress = ConfigurationManager.AppSettings["SEND_MAIL_FROM_EMAIL_ADDRESS"];
static var smtpClientAddress = ConfigurationManager.AppSettings["SEND_MAIL_SMTP_CLIENT_ADDRESS"];
static var toEmailAddress = ConfigurationManager.AppSettings["SEND_MAIL_TO_EMAIL_ADDRESS"];
static var mailSubject = ConfigurationManager.AppSettings["SEND_MAIL_SUBJECT"];

static var functionAppName = ConfigurationManager.AppSettings["FUNCTION_APP_NAME"];
static var environment = ConfigurationManager.AppSettings["ENVIRONMENT"];

public async static Task Run(string myEventHubMessage, TraceWriter log, ExecutionContext context)
{
    try
    {
        BookingStatusResponse bookingStatusResponse = null;
        dynamic objjson = JValue.Parse(myEventHubMessage);

        string message_type = objjson.message_type;
        if (!string.IsNullOrEmpty(message_type))
        {
            if (message_type.Equals("workflow_completion.create"))
            {
                string workflow_type = null;
                string booking_reference = null;
                string booking_reference_to_cosmos = null;
                string outcome = null;
                bool is_successful = false;
                string driver_ext_ref = null;
                string booking_failure_reason = null;

                try
                {
                    workflow_type = objjson.message_data.workflow_completion.workflow_type;
                }
                catch (Exception)
                {

                }
                if (!string.IsNullOrEmpty(workflow_type) && workflow_type.Equals("pickup"))
                {
                    try
                    {
                        outcome = objjson.message_data.workflow_completion.outcome;
                        booking_reference = objjson.message_data.workflow_completion.stop_completions[0].stop_ext_ref;
                        booking_reference_to_cosmos = booking_reference.Contains("_") ? booking_reference.Substring(0, booking_reference.IndexOf("_")) : booking_reference;
                        is_successful = objjson.message_data.workflow_completion.is_successful;
                        driver_ext_ref = objjson.message_data.workflow_completion.driver_ext_ref;
                        booking_failure_reason = objjson.message_data.workflow_completion.custom_data.other_failure_reason;
                    }
                    catch (Exception)
                    {

                    }

                    string uniqueID = GetUniqueID(booking_reference_to_cosmos, driver_ext_ref);
                    string booking_status = null;
                    if (!string.IsNullOrEmpty(workflow_type) && !string.IsNullOrEmpty(booking_reference_to_cosmos) && !string.IsNullOrEmpty(outcome))
                    {
                        workflow_type = workflow_type.Trim().ToLower();
                        booking_reference_to_cosmos = booking_reference_to_cosmos.Trim().ToLower();
                        outcome = outcome.Trim().ToLower();

                        if (outcome.Equals("pickup") && is_successful)
                        {
                            booking_status = "Completed";
                        }
                        else if (outcome.Equals("failed-wrong-job") && !is_successful)
                        {
                            booking_status = "Wrong job";
                        }
                        else if (new[] { "failed-closed", "failed-damaged", "failed-defer", "failed-goods-not-ready", "failed-incomplete", "failed-no-access-available", "failed-no-goods-to-go",
                "failed-not-home-or-closed", "failed-other", "failed-pickup", "failed-refused-by-customer", "failed-unable-to-transport", "failed-unsafe-to-leave" }.Any(o => outcome.StartsWith(o))
                        && !is_successful)
                        {
                            booking_status = "Futile";
                        }

                        JObject bookingStatusRequest = null;

                        if (!outcome.Equals("failed-defer"))
                        {
                            bookingStatusRequest = GetBookingRequest(uniqueID, booking_status, booking_reference_to_cosmos, outcome, booking_failure_reason);
                            bookingStatusResponse = await InvokeBookingAPI(bookingStatusRequest);
                        }

                        await SQLAudit(myEventHubMessage, uniqueID, driver_ext_ref, booking_status, booking_reference, booking_reference_to_cosmos, outcome, booking_failure_reason, bookingStatusRequest == null ? null : bookingStatusRequest.ToString(), bookingStatusResponse);

                        if (outcome.Equals("failed-defer"))
                        {
                            string bookingType = null;
                            string branch = null;
                            string channel = null;
                            string accountNumber = null;
                            string pickupCompanyName = null;
                            string pickupContactName = null;
                            string pickupAddress1 = null;
                            string pickupSuburb = null;
                            string pickupState = null;
                            string pickupPostcode = null;
                            string pickupEmail = null;
                            string pickupFrom = null;
                            string pickupDate = null;
                            string pickupTime = null;
                            string orderCoupons = null;
                            string deliveryCompanyName = null;
                            string deliveryContactName = null;
                            string deliveryAddress1 = null;
                            string deliverySuburb = null;
                            string deliveryState = null;
                            string deliveryPostcode = null;
                            string deliveryEmail = null;

                            string queryString = "SELECT TOP 1 [json_from_nowgo] FROM [nowgo_bookings] WHERE booking_reference_to_cosmos = @booking_reference_to_cosmos AND [booking_status] = 'Accepted' ORDER BY [row_id] DESC";

                            string paramValue = booking_reference_to_cosmos;

                            using (SqlCommand sqlCommand = new SqlCommand(queryString, sqlConnection))
                            {
                                sqlCommand.Parameters.AddWithValue("@booking_reference_to_cosmos", paramValue);
                                sqlCommand.CommandTimeout = 120;
                                ConnectionState connectionState = sqlConnection.State;
                                if (connectionState != ConnectionState.Open)
                                {
                                    if (connectionState != ConnectionState.Closed)
                                    {
                                        sqlConnection.Close();
                                    }
                                    sqlConnection.Open();
                                }

                                string strJobObj = Convert.ToString(await sqlCommand.ExecuteScalarAsync());

                                dynamic jsonJobObj = JValue.Parse(strJobObj);
                                bookingType = jsonJobObj.message_data.job.data.Booking_Type;
                                if (driver_ext_ref.Substring(3, 3).ToUpper() != "OOL")
                                {
                                    branch = GetBranch(driver_ext_ref.Substring(0, 3).ToUpper());
                                }
                                else
                                {
                                    branch = GetBranch(driver_ext_ref.Substring(3, 3).ToUpper());

                                }
                                accountNumber = jsonJobObj.message_data.job.data.Account_Number;
                                channel = jsonJobObj.message_data.job.channel_ext_ref;
                                pickupCompanyName = jsonJobObj.message_data.job.data.Pickup_Company_Name;
                                pickupContactName = jsonJobObj.message_data.job.data.Pickup_Contact_Name;
                                pickupSuburb = jsonJobObj.message_data.job.stops[0].location.locality;
                                pickupState = jsonJobObj.message_data.job.stops[0].location.state;
                                pickupPostcode = jsonJobObj.message_data.job.stops[0].location.postal_code;
                                pickupAddress1 = jsonJobObj.message_data.job.stops[0].location.address;
                                pickupAddress1 = pickupAddress1.Replace(pickupSuburb, "");
                                pickupAddress1 = pickupAddress1.Replace(pickupState, "");
                                pickupAddress1 = pickupAddress1.Replace(pickupPostcode, "");
                                pickupAddress1 = pickupAddress1.Replace("Australia", "");
                                pickupAddress1 = pickupAddress1.Replace(",", "");
                                pickupAddress1 = pickupAddress1.Trim();
                                pickupEmail = jsonJobObj.message_data.job.data.Pickup_Email;
                                pickupFrom = jsonJobObj.message_data.job.data.Pickup_From;
                                DateTime pickupDateByState = GetPickupDateByState(pickupState);
                                pickupDate = pickupDateByState.ToString("dd/MM/yyyy");
                                pickupTime = pickupDateByState.ToString("hh:mm tt");
                                orderCoupons = jsonJobObj.message_data.job.data.Order_Coupons;
                                deliveryCompanyName = jsonJobObj.message_data.job.data.Delivery_Company_Name;
                                deliveryContactName = jsonJobObj.message_data.job.data.Delivery_Contact_Name;
                                deliveryAddress1 = jsonJobObj.message_data.job.data.Delivery_Address;
                                deliverySuburb = jsonJobObj.message_data.job.data.Delivery_Suburb;
                                deliveryState = jsonJobObj.message_data.job.data.Delivery_State;
                                deliveryPostcode = jsonJobObj.message_data.job.data.Delivery_Post_Code;
                                deliveryEmail = jsonJobObj.message_data.job.data.delivery_email;
                                string rebooking_ref = GetRebookingRef(booking_reference);

                                JObject objChild = new JObject
                                {
                                    { "branch", branch },
                                    { "channel", channel },
                                    { "driverRef", driver_ext_ref },
                                    { "accountNumber", accountNumber },
                                    { "uniqueID",  rebooking_ref},
                                    { "bookingType", bookingType },
                                    { "pickupCompanyName", pickupCompanyName },
                                    { "pickupContactName", pickupContactName },
                                    { "pickupAddress1", pickupAddress1 },
                                    { "pickupSuburb", pickupSuburb },
                                    { "pickupState", pickupState },
                                    { "pickupPostcode", pickupPostcode },
                                    { "pickupEmail", pickupEmail },
                                    { "pickupDate", pickupDate },
                                    { "pickupTime", pickupTime },
                                    { "pickupFrom", pickupFrom },
                                    { "orderCoupons", orderCoupons },
                                    { "deliveryCompanyName", deliveryCompanyName },
                                    { "deliveryContactName", deliveryContactName },
                                    { "deliveryAddress1", deliveryAddress1 },
                                    { "deliverySuburb", deliverySuburb },
                                    { "deliveryState", deliveryState },
                                    { "deliveryPostcode", deliveryPostcode },
                                    { "deliveryEmail", deliveryEmail },
                                };

                                JObject bookingAPIRequest = new JObject
                                {
                                    { "Booking", objChild }
                                };

                                CPBookingAPIResponse cpBookingAPIResponse = await InvokeCPBookingAPI(bookingAPIRequest);

                                await SQLAudit_Rebooking(booking_reference, rebooking_ref, accountNumber, branch, driver_ext_ref, bookingAPIRequest.ToString(), cpBookingAPIResponse);
                            }
                        }
                    }
                }
            }
            else if (message_type.StartsWith("job."))
            {
                string booking_reference = null;
                string booking_reference_to_cosmos = null;
                string shift_id = null;
                bool closed = false;
                string last_completed_in_shift = null;
                string driver_ext_ref = null;
                try
                {
                    try
                    {
                        booking_reference = objjson.message_data.job.ext_ref;
                        booking_reference_to_cosmos = booking_reference.Contains("_") ? booking_reference.Substring(0, booking_reference.IndexOf("_")) : booking_reference;
                    }
                    catch (Exception)
                    {
                        booking_reference = objjson.message_data.job.stops[0].ext_ref;
                        booking_reference_to_cosmos = booking_reference.Contains("_") ? booking_reference.Substring(0, booking_reference.IndexOf("_")) : booking_reference;
                    }
                    shift_id = objjson.message_data.job.stops[0].shift_id;
                    closed = objjson.message_data.job.stops[0].closed;
                    last_completed_in_shift = objjson.message_data.job.stops[0].last_completed_in_shift;
                    driver_ext_ref = objjson.message_data.job.allowed_driver_ext_refs[0];
                }
                catch (Exception)
                {

                }

                string booking_status = null;
                JObject bookingStatusRequest = null;

                string uniqueID = GetUniqueID(booking_reference_to_cosmos, driver_ext_ref);
                if (!closed && !string.IsNullOrEmpty(booking_reference_to_cosmos))
                {
                    booking_reference_to_cosmos = booking_reference_to_cosmos.Trim().ToLower();
                    if (shift_id == null && last_completed_in_shift == null)
                    {
                        booking_status = "Not received";
                    }
                    else if (!string.IsNullOrEmpty(shift_id))
                    {
                        booking_status = "Accepted";
                        bookingStatusRequest = GetBookingRequest(uniqueID, booking_status, booking_reference_to_cosmos, null, null);
                        bookingStatusResponse = await InvokeBookingAPI(bookingStatusRequest);
                    }

                    await SQLAudit(myEventHubMessage, uniqueID, driver_ext_ref, booking_status, booking_reference, booking_reference_to_cosmos, null, null, bookingStatusRequest == null ? null : bookingStatusRequest.ToString(), bookingStatusResponse);
                }
            }
        }
    }
    catch (Exception ex)
    {
        using (MailMessage mail = new MailMessage { From = new MailAddress(fromEmailAddress) })
        {
            mail.To.Add(toEmailAddress);
            mail.Subject = mailSubject;

            StringBuilder mailBody = new StringBuilder();
            mailBody.AppendLine("Please find attached, the incoming json data!");
            mailBody.AppendLine();
            mailBody.AppendLine("Azure Function App : " + functionAppName + Environment.NewLine);
            mailBody.AppendLine("Azure Function : " + context.FunctionName + Environment.NewLine);
            mailBody.AppendLine("Environment : " + environment + Environment.NewLine);
            mailBody.AppendLine(GetFullExceptionDetails(ex));
            mail.Body = mailBody.ToString();

            byte[] byteArray = Encoding.ASCII.GetBytes(myEventHubMessage);
            using (MemoryStream stream = new MemoryStream(byteArray))
            {
                stream.Position = 0;
                mail.Attachments.Add(new Attachment(stream, "incoming_data.json", "text/json"));


                using (SmtpClient smtpClient = new SmtpClient(smtpClientAddress)
                {
                    Port = 587,
                    Credentials = new System.Net.NetworkCredential(username, password),
                    EnableSsl = true
                })
                {
                    smtpClient.Send(mail);
                }
            }
        }

        using (var sqlCommand = new SqlCommand("insert_nowgo_bookings_failed_transactions", sqlConnection))
        {
            sqlCommand.CommandType = CommandType.StoredProcedure;
            sqlCommand.Parameters.Add("@json", SqlDbType.NVarChar).Value = myEventHubMessage;
            sqlCommand.Parameters.Add("@exception_stack_trace", SqlDbType.NVarChar).Value = GetFullExceptionDetails(ex);
            ConnectionState connectionState = sqlConnection.State;
            if (connectionState != ConnectionState.Open)
            {
                if (connectionState != ConnectionState.Closed)
                {
                    sqlConnection.Close();
                }
                sqlConnection.Open();
            }
            await sqlCommand.ExecuteNonQueryAsync();
        }
        throw ex;
    }
}

private static DateTime GetPickupDateByState(string state)
{
    string zode_id = null;
    switch (state)
    {
        case "WA":
            zode_id = "W. Australia Standard Time";
            break;
        case "NSW":
            zode_id = "AUS Eastern Standard Time";
            break;
        case "QLD":
            zode_id = "E. Australia Standard Time";
            break;
        case "VIC":
            zode_id = "AUS Eastern Standard Time";
            break;
        case "ACT":
            zode_id = "AUS Eastern Standard Time";
            break;
        case "TAS":
            zode_id = "AUS Eastern Standard Time";
            break;
        case "SA":
            zode_id = "Cen. Australia Standard Time";
            break;
        case "NT":
            zode_id = "AUS Central Standard Time";
            break;

    }
    DateTime timeUtc = DateTime.UtcNow;
    TimeZoneInfo zone = TimeZoneInfo.FindSystemTimeZoneById(zode_id);
    return TimeZoneInfo.ConvertTimeFromUtc(timeUtc, zone);
}

private static string GetRebookingRef(string booking_reference)
{
    string rebooking_ref = null;
    int str_rebooking_ref_counter;

    if (booking_reference.Contains("_"))
    {
        str_rebooking_ref_counter = Convert.ToInt16(booking_reference.Substring(booking_reference.IndexOf("_") + 1));

        str_rebooking_ref_counter += str_rebooking_ref_counter;

        rebooking_ref = booking_reference.Substring(0, booking_reference.IndexOf("_"));
    }
    else
    {
        str_rebooking_ref_counter = 1;
        rebooking_ref = booking_reference;
    }

    rebooking_ref = rebooking_ref + "_" + str_rebooking_ref_counter.ToString().PadLeft(2, '0');
    return rebooking_ref;
}

private async static Task<BookingStatusResponse> InvokeBookingAPI(JObject inputRequest)
{
    using (HttpClient client = new HttpClient())
    {
        client.DefaultRequestHeaders.Accept.Clear();
        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        client.DefaultRequestHeaders.Add("COSMOS_API_KEY", apiKey);
        ServicePointManager.Expect100Continue = true;
        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                | SecurityProtocolType.Tls11
                | SecurityProtocolType.Tls12
                | SecurityProtocolType.Ssl3;

        string json = JsonConvert.SerializeObject(inputRequest);
        var requestData = new StringContent(json, Encoding.UTF8, "application/json");
        var response = await client.PostAsync(String.Format(apiEndPoint), requestData);
        BookingStatusResponse bookingStatusResponse = await response.Content.ReadAsAsync<BookingStatusResponse>();
        return bookingStatusResponse;
    }
}

private static async Task<CPBookingAPIResponse> InvokeCPBookingAPI(JObject inputRequest)
{
    using (HttpClient client = new HttpClient())
    {
        client.DefaultRequestHeaders.Accept.Clear();
        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        client.DefaultRequestHeaders.Add("ServiceID", cpBookingAPI_ServiceID);
        client.DefaultRequestHeaders.Add("ClientCode", cpBookingAPI_ClientCode);
        ServicePointManager.Expect100Continue = true;
        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                | SecurityProtocolType.Tls11
                | SecurityProtocolType.Tls12
                | SecurityProtocolType.Ssl3;

        string json = JsonConvert.SerializeObject(inputRequest);
        StringContent requestData = new StringContent(json, Encoding.UTF8, "application/json");
        HttpResponseMessage response = await client.PostAsync(cpBookingAPI_Endpoint, requestData);
        CPBookingAPIResponse cpBookingAPIResponse = await response.Content.ReadAsAsync<CPBookingAPIResponse>();
        return cpBookingAPIResponse;
    }
}

private static JObject GetBookingRequest(string uniqueID, string booking_status, string booking_reference, string booking_outcome, string booking_failure_reason)
{
    JObject objChild = new JObject
    {
        { "uniqueID", uniqueID },
        { "booking_status", booking_status },
        { "booking_reference", booking_reference },
        { "booking_outcome", booking_outcome },
        { "booking_failure_reason", booking_failure_reason },
    };

    JObject bookingStatusRequest = new JObject
    {
        { "BookingStatus", objChild }
    };
    return bookingStatusRequest;
}

private static string GetUniqueID(string booking_reference, string driver_ext_ref)
{
    string uniqueID = null;
    if (!string.IsNullOrEmpty(booking_reference) && new[] { "brisbane", "melbourne", "sydney", "goldcoast", "adelaide", "perth" }.Any(branch => booking_reference.ToLower().StartsWith(branch)))
    {
        uniqueID = booking_reference;
    }
    else if (!string.IsNullOrEmpty(driver_ext_ref) && driver_ext_ref.Length >= 3)
    {
        string driver_ref_prefix = driver_ext_ref.Substring(0, 3);
        uniqueID = GetBranch(driver_ref_prefix.ToUpper());
    }
    return uniqueID;
}

private static string GetBranch(string branch_prefix)
{
    string branch = null;

    switch (branch_prefix)
    {
        case "QLD":
            branch = "brisbane";
            break;
        case "VIC":
            branch = "melbourne";
            break;
        case "NSW":
            branch = "sydney";
            break;
        case "OOL":
            branch = "goldcoast";
            break;
        case "STH":
            branch = "adelaide";
            break;
        case "WST":
            branch = "perth";
            break;
    }
    return branch;
}

private static async Task SQLAudit(string myEventHubMessage, string uniqueID, string driver_ext_ref, string booking_status, string booking_reference, string booking_reference_to_cosmos, string booking_outcome, string booking_failure_reason, string bookingStatusRequest, BookingStatusResponse bookingStatusResponse)
{
    using (SqlCommand sqlCommand = new SqlCommand("insert_nowgo_bookings", sqlConnection))
    {
        sqlCommand.CommandType = CommandType.StoredProcedure;
        sqlCommand.Parameters.Add("@unique_id", SqlDbType.VarChar).Value = uniqueID;
        sqlCommand.Parameters.Add("@driver_ref", SqlDbType.VarChar).Value = driver_ext_ref;
        sqlCommand.Parameters.Add("@booking_status", SqlDbType.VarChar).Value = booking_status;
        sqlCommand.Parameters.Add("@booking_reference", SqlDbType.VarChar).Value = booking_reference;
        sqlCommand.Parameters.Add("@booking_reference_to_cosmos", SqlDbType.VarChar).Value = booking_reference_to_cosmos;
        sqlCommand.Parameters.Add("@booking_outcome", SqlDbType.VarChar).Value = booking_outcome;
        sqlCommand.Parameters.Add("@booking_failure_reason", SqlDbType.VarChar).Value = booking_failure_reason;
        sqlCommand.Parameters.Add("@api_response_code", SqlDbType.VarChar).Value = bookingStatusResponse == null ? null : bookingStatusResponse.responseCode;
        sqlCommand.Parameters.Add("@api_response_status_code", SqlDbType.VarChar).Value = bookingStatusResponse == null ? null : bookingStatusResponse.statusCode;
        sqlCommand.Parameters.Add("@api_response_msg", SqlDbType.VarChar).Value = bookingStatusResponse == null ? null : bookingStatusResponse.msg;
        sqlCommand.Parameters.Add("@api_response_id", SqlDbType.VarChar).Value = bookingStatusResponse == null ? null : bookingStatusResponse.id;
        sqlCommand.Parameters.Add("@json_from_nowgo", SqlDbType.NVarChar).Value = myEventHubMessage;
        sqlCommand.Parameters.Add("@json_to_api", SqlDbType.NVarChar).Value = bookingStatusRequest;

        ConnectionState connectionState = sqlConnection.State;
        if (connectionState != ConnectionState.Open)
        {
            if (connectionState != ConnectionState.Closed)
            {
                sqlConnection.Close();
            }
            sqlConnection.Open();
        }
        await sqlCommand.ExecuteNonQueryAsync();
    }
}

private static async Task SQLAudit_Rebooking(string booking_ref, string rebooking_ref, string account_number, string branch, string driver_ref, string bookingAPIRequest, CPBookingAPIResponse cpBookingAPIResponse)
{
    using (SqlCommand sqlCommand = new SqlCommand("insert_nowgo_rebookings", sqlConnection))
    {
        sqlCommand.CommandType = CommandType.StoredProcedure;
        sqlCommand.Parameters.Add("@booking_ref", SqlDbType.VarChar).Value = booking_ref;
        sqlCommand.Parameters.Add("@rebooking_ref", SqlDbType.VarChar).Value = rebooking_ref;
        sqlCommand.Parameters.Add("@branch", SqlDbType.VarChar).Value = branch;
        sqlCommand.Parameters.Add("@driver_ref", SqlDbType.VarChar).Value = driver_ref;
        sqlCommand.Parameters.Add("@account_number", SqlDbType.VarChar).Value = account_number;
        sqlCommand.Parameters.Add("@api_response_code", SqlDbType.VarChar).Value = cpBookingAPIResponse == null ? null : cpBookingAPIResponse.responseCode;
        sqlCommand.Parameters.Add("@api_response_status_code", SqlDbType.VarChar).Value = cpBookingAPIResponse == null ? null : cpBookingAPIResponse.statusCode;
        sqlCommand.Parameters.Add("@api_response_msg", SqlDbType.VarChar).Value = cpBookingAPIResponse == null ? null : cpBookingAPIResponse.msg;
        sqlCommand.Parameters.Add("@api_response_booking_reference", SqlDbType.VarChar).Value = cpBookingAPIResponse != null && cpBookingAPIResponse.data != null ? cpBookingAPIResponse.data.bookingReferenceNo : null;
        sqlCommand.Parameters.Add("@api_response_nowgo_job_id", SqlDbType.VarChar).Value = cpBookingAPIResponse != null && cpBookingAPIResponse.data != null ? cpBookingAPIResponse.data.nowgoJobID : null;
        sqlCommand.Parameters.Add("@api_request", SqlDbType.NVarChar).Value = bookingAPIRequest;

        ConnectionState connectionState = sqlConnection.State;
        if (connectionState != ConnectionState.Open)
        {
            if (connectionState != ConnectionState.Closed)
            {
                sqlConnection.Close();
            }
            sqlConnection.Open();
        }
        await sqlCommand.ExecuteNonQueryAsync();
    }
}

public class BookingStatusResponse
{
    public string responseCode { get; set; }
    public string statusCode { get; set; }
    public string msg { get; set; }
    public string id { get; set; }
}
public class Data
{
    public string bookingReferenceNo { get; set; }
    public string nowgoJobID { get; set; }
}

public class CPBookingAPIResponse
{
    public string responseCode { get; set; }
    public string statusCode { get; set; }
    public object msg { get; set; }
    public Data data { get; set; }
}

private static string GetFullExceptionDetails(Exception exception)
{
    System.Text.StringBuilder stringBuilder = new System.Text.StringBuilder();

    while (exception != null)
    {
        stringBuilder.AppendLine("Error Message: ");
        stringBuilder.AppendLine(exception.Message);
        stringBuilder.AppendLine();
        stringBuilder.AppendLine("Exception Stack Trace: ");
        stringBuilder.AppendLine(exception.StackTrace);
        exception = exception.InnerException;
    }

    return stringBuilder.ToString();
}
